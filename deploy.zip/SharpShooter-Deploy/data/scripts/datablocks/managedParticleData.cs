
datablock ParticleData(newParticle : DefaultParticle)
{
};

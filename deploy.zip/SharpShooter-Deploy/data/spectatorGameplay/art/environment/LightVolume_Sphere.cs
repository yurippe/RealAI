
singleton TSShapeConstructor(LightVolume_SphereDAE)
{
   baseShape = "./LightVolume_Sphere.DAE";
   lodType = "TrailingNumber";
   neverImport = "env*";
   loadLights = "0";
};

datablock StaticShapeData(ObstacleData){
  shapeFile = "data/spectatorGameplay/art/GameShapes/player.dts";
};
